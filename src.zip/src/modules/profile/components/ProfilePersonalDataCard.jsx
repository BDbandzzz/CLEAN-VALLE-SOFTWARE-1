import { User, Mail, Save, X, CheckCircle, AlertCircle } from 'lucide-react';

import { Button } from '@/core/components/ui/button';
import { Input } from '@/core/components/ui/input';
import { Label } from '@/core/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/core/components/ui/card';

/**
 * Formulario de datos personales (solo correo editable).
 */
export function ProfilePersonalDataCard({
  formData,
  message,
  isSaving,
  onEmailChange,
  onSave,
  onReset,
}) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <User className="size-5 text-primary" aria-hidden />
          Datos personales
        </CardTitle>
        <CardDescription>
          Solo el correo electrónico es editable; el resto viene del registro institucional.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-5">
        <div className="grid gap-4 sm:grid-cols-2">
          <div className="space-y-2">
            <Label htmlFor="fullName">Nombres </Label>
            <Input
              id="fullName"
              readOnly
              tabIndex={-1}
              value={formData.fullName}
              placeholder="Nombre y apellido"
              className="cursor-default bg-muted/50"
            />
          </div>

                 <div className="space-y-2">
            <Label htmlFor="fullName">Apellidos </Label>
            <Input
              id="fullName"
              readOnly
              tabIndex={-1}
              value={formData.fullName}
              placeholder="Nombre y apellido"
              className="cursor-default bg-muted/50"
            />
            </div>
        
          <div className="space-y-2">
            <Label htmlFor="email">Correo electrónico</Label>
            <div className="relative">
              <Mail className="pointer-events-none absolute left-2.5 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                id="email"
                className="pl-9"
                type="email"
                value={formData.email}
                onChange={(e) => onEmailChange(e.target.value)}
                placeholder="correo@univalle.edu.co"
              />
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="dniUser">Documento</Label>
            <Input
              id="dniUser"
              readOnly
              tabIndex={-1}
              value={formData.dniUser}
              placeholder="Número de documento"
              className="cursor-default bg-muted/50"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="typeDni">Tipo de documento</Label>
            <Input
              id="typeDni"
              readOnly
              tabIndex={-1}
              value={formData.typeDni}
              placeholder="CC, TI, CE, PAS…"
              className="cursor-default bg-muted/50"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="gender">Género</Label>
            <Input
              id="gender"
              readOnly
              tabIndex={-1}
              value={formData.gender}
              placeholder="Opcional"
              className="cursor-default bg-muted/50"
            />
          </div>
        </div>

        {message.text ? (
          <div
            className={`flex items-center gap-2 rounded-lg border p-3 text-sm ${
              message.type === 'success'
                ? 'border-emerald-200 bg-emerald-50 text-emerald-900'
                : 'border-red-200 bg-red-50 text-red-900'
            }`}
          >
            {message.type === 'success' ? (
              <CheckCircle className="size-4 shrink-0" aria-hidden />
            ) : (
              <AlertCircle className="size-4 shrink-0" aria-hidden />
            )}
            {message.text}
          </div>
        ) : null}

        <div className="flex flex-wrap gap-3 pt-2">
          <Button onClick={onSave} disabled={isSaving} className="gap-2">
            {isSaving ? (
              <span className="inline-flex items-center gap-2">
                <span className="size-4 animate-spin rounded-full border-2 border-primary-foreground border-t-transparent" />
                Guardando…
              </span>
            ) : (
              <>
                <Save className="size-4" aria-hidden />
                Guardar cambios
              </>
            )}
          </Button>
          <Button type="button" variant="outline" onClick={onReset} className="gap-2">
            <X className="size-4" aria-hidden />
            Restablecer
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
