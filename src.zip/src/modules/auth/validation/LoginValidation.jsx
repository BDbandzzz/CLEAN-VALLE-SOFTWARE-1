/**
 * Reglas de negocio y validación del login (sin UI).
 * El diseño vive en `LoginPage.jsx`.
 */

export const defaultLoginProfile = {
  fullName: '',
  email: '',
  dniUser: '',
  typeDni: '',
  gender: '',
  userCredentials: '',
};

export function getRoleFromCredentials(codeValue) {
  const normalized = String(codeValue).toLowerCase().trim();

  if (normalized === '2455194-2724') {
    return 'estudiante';
  }
  if (normalized.startsWith('pro')) {
    return 'profesor';
  }
  if (normalized.startsWith('ope')) {
    return 'operador';
  }
  if (normalized.startsWith('adm')) {
    return 'admin';
  }

  return 'estudiante';
}

export function buildLoginUserPayload(code, password = '') {
  void password;
  const trimmed = code.trim();
  const role = getRoleFromCredentials(trimmed);

  return {
    id: trimmed || `user_${Date.now()}`,
    fullName: 'Usuario Test',
    dniUser: trimmed || `TEST${Date.now()}`,
    role,
    ...defaultLoginProfile,
  };
}
